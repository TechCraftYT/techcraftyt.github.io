All About Me Late 2024 written in C# for Windows. Download the Code for the executable to use.

Is basically just a program about my life currently. Really basic but fun to make.
